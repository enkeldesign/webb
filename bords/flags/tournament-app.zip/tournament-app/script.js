/*
 * Turneringsledar-appen: hanterar val av deltagare, gruppindelning,
 * matchresultat, tabeller och slutspel. Den här versionen använder
 * en generisk algoritm för att skapa grupper, matcher och slutspel
 * för 12–16 deltagare. All data sparas i minnet och uppdateras
 * när användaren matar in resultat.
 */

(function () {
  // Lista över tillgängliga lag med id, namn och flaggans sökväg.
  const availableTeams = [
    { id: 'albania', name: 'Albania', flag: 'assets/flags/Flag_of_Albania.svg' },
    { id: 'australia', name: 'Australia', flag: 'assets/flags/Flag_of_Australia.svg' },
    { id: 'belgium', name: 'Belgium', flag: 'assets/flags/Flag_of_Belgium.svg' },
    { id: 'canada', name: 'Canada', flag: 'assets/flags/Flag_of_Canada.svg' },
    { id: 'chile', name: 'Chile', flag: 'assets/flags/Flag_of_Chile.svg' },
    { id: 'cyprus', name: 'Cyprus', flag: 'assets/flags/Flag_of_Cyprus.svg' },
    { id: 'denmark', name: 'Denmark', flag: 'assets/flags/Flag_of_Denmark.svg' },
    { id: 'east_germany', name: 'East Germany', flag: 'assets/flags/Flag_of_East_Germany.svg' },
    { id: 'el_salvador', name: 'El Salvador', flag: 'assets/flags/Flag_of_El_Salvador.svg' },
    { id: 'england', name: 'England', flag: 'assets/flags/Flag_of_England.svg' },
    { id: 'finland', name: 'Finland', flag: 'assets/flags/Flag_of_Finland.svg' },
    { id: 'greece', name: 'Greece', flag: 'assets/flags/Flag_of_Greece.svg' },
    { id: 'iceland', name: 'Iceland', flag: 'assets/flags/Flag_of_Iceland.svg' },
    { id: 'india', name: 'India', flag: 'assets/flags/Flag_of_India.svg' },
    { id: 'iran', name: 'Iran', flag: 'assets/flags/Flag_of_Iran.svg' },
    { id: 'italy', name: 'Italy', flag: 'assets/flags/Flag_of_Italy.svg' },
    { id: 'japan', name: 'Japan', flag: 'assets/flags/Flag_of_Japan.svg' },
    { id: 'mali', name: 'Mali', flag: 'assets/flags/Flag_of_Mali.svg' },
    { id: 'malta', name: 'Malta', flag: 'assets/flags/Flag_of_Malta.svg' },
    { id: 'mexico', name: 'Mexico', flag: 'assets/flags/Flag_of_Mexico.svg' },
    { id: 'nauru', name: 'Nauru', flag: 'assets/flags/Flag_of_Nauru.svg' },
    { id: 'nepal', name: 'Nepal', flag: 'assets/flags/Flag_of_Nepal.svg' },
    { id: 'north_korea', name: 'North Korea', flag: 'assets/flags/Flag_of_North_Korea.svg' },
    { id: 'norway', name: 'Norway', flag: 'assets/flags/Flag_of_Norway.svg' },
    { id: 'peru', name: 'Peru', flag: 'assets/flags/Flag_of_Peru.svg' },
    { id: 'poland', name: 'Poland', flag: 'assets/flags/Flag_of_Poland.svg' },
    { id: 'saint_kitts_nevis', name: 'Saint Kitts and Nevis', flag: 'assets/flags/Flag_of_Saint_Kitts_and_Nevis.svg' },
    { id: 'scotland', name: 'Scotland', flag: 'assets/flags/Flag_of_Scotland.svg' },
    { id: 'spain', name: 'Spain', flag: 'assets/flags/Flag_of_Spain.svg' },
    { id: 'sweden', name: 'Sweden', flag: 'assets/flags/Flag_of_Sweden.svg' },
    { id: 'switzerland', name: 'Switzerland', flag: 'assets/flags/Flag_of_Switzerland.svg' },
    { id: 'trinidad_tobago', name: 'Trinidad and Tobago', flag: 'assets/flags/Flag_of_Trinidad_and_Tobago.svg' },
    { id: 'tunisia', name: 'Tunisia', flag: 'assets/flags/Flag_of_Tunisia.svg' },
    { id: 'ukraine', name: 'Ukraine', flag: 'assets/flags/Flag_of_Ukraine.svg' },
    { id: 'upper_volta', name: 'Upper Volta', flag: 'assets/flags/Flag_of_Upper_Volta.svg' },
    { id: 'yugoslavia', name: 'Yugoslavia', flag: 'assets/flags/Flag_of_Yugoslavia_(1946-1992).svg' },
    { id: 'faroe_islands', name: 'Faroe Islands', flag: 'assets/flags/Flag_of_the_Faroe_Islands.svg' },
    { id: 'soviet_union', name: 'Soviet Union', flag: 'assets/flags/Flag_of_the_Soviet_Union.svg' },
    { id: 'united_states', name: 'United States', flag: 'assets/flags/Flag_of_the_United_States.svg' },
    { id: 'aaland', name: 'Åland', flag: 'assets/flags/Flag_of_%C3%85land.svg' },
    { id: 'tamil_eelam', name: 'Tamil Eelam', flag: 'assets/flags/Tamil_Eelam_Flag.svg' }
  ];

  // Marathon-tabell som HTML. Detta ersätter Markdown-parsing och säkerställer att alla rader visas korrekt.
  const marathonHTML = `<table><thead><tr><th>Placering</th><th>Nation</th><th>Turneringar</th><th>Matcher</th><th>Vinster</th><th>Oavgjorda*</th><th>Förluster</th><th>Målskillnad</th><th>Poäng</th></tr></thead><tbody>
  <tr><td>01</td><td>Färöarna</td><td>11</td><td>68</td><td>58</td><td>8</td><td>2</td><td>318-89</td><td>124</td></tr>
  <tr><td>02</td><td>Jugoslavien</td><td>10</td><td>58</td><td>40</td><td>9</td><td>9</td><td>182-99</td><td>89</td></tr>
  <tr><td>03</td><td>Finland</td><td>8</td><td>47</td><td>33</td><td>7</td><td>7</td><td>184-67</td><td>73</td></tr>
  <tr><td>04</td><td>Sverige</td><td>9</td><td>49</td><td>28</td><td>10</td><td>11</td><td>140-93</td><td>66</td></tr>
  <tr><td>05</td><td>Nordkorea</td><td>9</td><td>47</td><td>25</td><td>7</td><td>15</td><td>131-94</td><td>57</td></tr>
  <tr><td>06</td><td>Chile</td><td>8</td><td>42</td><td>19</td><td>6</td><td>17</td><td>102-109</td><td>44</td></tr>
  <tr><td>07</td><td>Schweiz</td><td>9</td><td>43</td><td>18</td><td>4</td><td>21</td><td>87-106</td><td>40</td></tr>
  <tr><td>08</td><td>Australien</td><td>3</td><td>21</td><td>16</td><td>1</td><td>4</td><td>74-39</td><td>33</td></tr>
  <tr><td>09</td><td>Iran</td><td>6</td><td>30</td><td>11</td><td>5</td><td>14</td><td>63-93</td><td>27</td></tr>
  <tr><td>10</td><td>Tamil Eelam</td><td>6</td><td>25</td><td>10</td><td>4</td><td>11</td><td>48-56</td><td>24</td></tr>
  <tr><td>11</td><td>Kanada</td><td>5</td><td>26</td><td>8</td><td>7</td><td>11</td><td>55-59</td><td>23</td></tr>
  <tr><td>12</td><td>Albanien</td><td>5</td><td>21</td><td>8</td><td>3</td><td>10</td><td>44-55</td><td>19</td></tr>
  <tr><td>13</td><td>Peru</td><td>5</td><td>21</td><td>7</td><td>1</td><td>13</td><td>38-59</td><td>15</td></tr>
  <tr><td>14</td><td>Norge</td><td>6</td><td>22</td><td>5</td><td>2</td><td>15</td><td>28-57</td><td>12</td></tr>
  <tr><td>15</td><td>Västtyskland</td><td>3</td><td>13</td><td>4</td><td>2</td><td>7</td><td>21-25</td><td>10</td></tr>
  <tr><td>16</td><td>Belgien</td><td>2</td><td>10</td><td>4</td><td>2</td><td>4</td><td>17-21</td><td>10</td></tr>
  <tr><td>17</td><td>Mali</td><td>5</td><td>19</td><td>3</td><td>3</td><td>13</td><td>21-58</td><td>9</td></tr>
  <tr><td>18</td><td>El Salvador</td><td>2</td><td>8</td><td>3</td><td>2</td><td>3</td><td>18-15</td><td>8</td></tr>
  <tr><td>19</td><td>Italien</td><td>5</td><td>18</td><td>3</td><td>2</td><td>13</td><td>24-67</td><td>8</td></tr>
  <tr><td>20</td><td>Sovjetunionen</td><td>3</td><td>11</td><td>2</td><td>3</td><td>6</td><td>16-35</td><td>7</td></tr>
  <tr><td>21</td><td>Polen</td><td>2</td><td>8</td><td>3</td><td>0</td><td>5</td><td>14-19</td><td>6</td></tr>
  <tr><td>22</td><td>Nepal</td><td>2</td><td>9</td><td>2</td><td>2</td><td>5</td><td>16-30</td><td>6</td></tr>
  <tr><td>23</td><td>Indien</td><td>3</td><td>12</td><td>3</td><td>0</td><td>9</td><td>15-44</td><td>6</td></tr>
  <tr><td>24</td><td>Nauru</td><td>6</td><td>22</td><td>1</td><td>4</td><td>17</td><td>28-72</td><td>6</td></tr>
  <tr><td>25</td><td>Östtyskland</td><td>4</td><td>14</td><td>1</td><td>3</td><td>10</td><td>19-37</td><td>5</td></tr>
  <tr><td>26</td><td>Skottland</td><td>4</td><td>14</td><td>2</td><td>1</td><td>11</td><td>8-45</td><td>5</td></tr>
  <tr><td>27</td><td>Danmark</td><td>1</td><td>4</td><td>2</td><td>0</td><td>2</td><td>11-10</td><td>4</td></tr>
  <tr><td>28</td><td>Grekland</td><td>1</td><td>5</td><td>2</td><td>0</td><td>3</td><td>10-13</td><td>4</td></tr>
  <tr><td>29</td><td>St: Kitts/Nevis</td><td>2</td><td>8</td><td>1</td><td>1</td><td>6</td><td>7-18</td><td>3</td></tr>
  <tr><td>30</td><td>Övre Volta</td><td>4</td><td>14</td><td>0</td><td>3</td><td>11</td><td>10-37</td><td>3</td></tr>
  <tr><td>31</td><td>Cypern</td><td>1</td><td>3</td><td>1</td><td>0</td><td>2</td><td>5-5</td><td>2</td></tr>
  <tr><td>32</td><td>USA</td><td>1</td><td>4</td><td>1</td><td>0</td><td>3</td><td>4-8</td><td>2</td></tr>
  <tr><td>33</td><td>England</td><td>1</td><td>5</td><td>1</td><td>0</td><td>4</td><td>5-15</td><td>2</td></tr>
  <tr><td>34</td><td>Spanien</td><td>2</td><td>6</td><td>0</td><td>1</td><td>5</td><td>7-20</td><td>1</td></tr>
  <tr><td>35</td><td>Mexiko</td><td>1</td><td>4</td><td>0</td><td>0</td><td>4</td><td>6-16</td><td>0</td></tr>
  <tr><td>36</td><td>Tunisien</td><td>1</td><td>3</td><td>0</td><td>0</td><td>3</td><td>2-13</td><td>0</td></tr>
  <tr><td>37</td><td>Rhodesia</td><td>1</td><td>4</td><td>0</td><td>0</td><td>4</td><td>3-15</td><td>0</td></tr>
  <tr><td>38</td><td>Malta</td><td>1</td><td>4</td><td>0</td><td>0</td><td>4</td><td>4-20</td><td>0</td></tr>
  <tr><td>39</td><td>Japan</td><td>2</td><td>7</td><td>0</td><td>0</td><td>7</td><td>5-31</td><td>0</td></tr>
  <tr><td>40</td><td>Trinidad/Tobago</td><td>1</td><td>4</td><td>0</td><td>0</td><td>4</td><td>1-27</td><td>0</td></tr>
  </tbody></table>`;

  // Globala variabler för applikationens tillstånd.
  let selectedNumParticipants = 12;
  let numTables = 1;
  let selectedTeams = [];
  let groupConfig = [];
  let groupLabels = [];
  let slotAssignments = {}; // t.ex. {A1: 'sweden', A2: 'norway', ...}
  let matches = [];
  let groupTables = {};
  let playoffBracket = [];
  let playoffStage = false;

  // Initiera appen vid sidladdning.
  document.addEventListener('DOMContentLoaded', () => {
    populateParticipantOptions();
    renderTeamSelection();
    parseMarathonTable();
    addEventListeners();
  });

  // Fyll i antal deltagare från 12 till 16 i dropdown.
  function populateParticipantOptions() {
    const select = document.getElementById('numParticipants');
    [12, 13, 14, 15, 16].forEach(num => {
      const option = document.createElement('option');
      option.value = num;
      option.textContent = num;
      select.appendChild(option);
    });
    selectedNumParticipants = parseInt(select.value, 10);
  }

  // Rendera kort för att välja lag.
  function renderTeamSelection() {
    const container = document.getElementById('team-selection');
    container.innerHTML = '';
    availableTeams.forEach(team => {
      const card = document.createElement('div');
      card.className = 'team-card';
      card.dataset.id = team.id;
      card.innerHTML = `<img src="${team.flag}" alt="${team.name}" /><span>${team.name}</span>`;
      card.addEventListener('click', () => toggleTeamSelection(team.id));
      container.appendChild(card);
    });
    updateTeamCardStates();
  }

  // Uppdatera visuell markering av valda lag.
  function updateTeamCardStates() {
    const cards = document.querySelectorAll('.team-card');
    cards.forEach(card => {
      if (selectedTeams.includes(card.dataset.id)) {
        card.classList.add('selected');
      } else {
        card.classList.remove('selected');
      }
    });
  }

  // Toggle selection of a team.
  function toggleTeamSelection(teamId) {
    const idx = selectedTeams.indexOf(teamId);
    if (idx >= 0) {
      selectedTeams.splice(idx, 1);
    } else {
      if (selectedTeams.length >= selectedNumParticipants) {
        alert(`Du kan endast välja ${selectedNumParticipants} lag.`);
        return;
      }
      selectedTeams.push(teamId);
    }
    updateTeamCardStates();
  }

  // Parsar marathon-tabellen till HTML och lägger in den i maraton-fliken.
  function parseMarathonTable() {
    const container = document.getElementById('marathon-table');
    if (!container) return;
    // Använd den förgenererade HTML-tabellen istället för att parsa Markdown.
    container.innerHTML = marathonHTML;
  }

  // Lägger till händelselyssnare på kontroller.
  function addEventListeners() {
    document.getElementById('numParticipants').addEventListener('change', (e) => {
      selectedNumParticipants = parseInt(e.target.value, 10);
      // Om fler lag är valda än nya gränsen, beskär listan.
      if (selectedTeams.length > selectedNumParticipants) {
        selectedTeams = selectedTeams.slice(0, selectedNumParticipants);
        updateTeamCardStates();
      }
    });
    document.getElementById('numTables').addEventListener('change', (e) => {
      numTables = Math.max(1, parseInt(e.target.value, 10) || 1);
      // uppdatera matchlistan om turneringen redan startat
      if (matches.length > 0 && !playoffStage) renderMatches();
    });
    document.getElementById('calculate-btn').addEventListener('click', () => handleCalculate());
    document.getElementById('start-tournament-btn').addEventListener('click', () => handleStartTournament());
    // Tab-knappar
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });
  }

  // När användaren trycker "Fortsätt" i setup: kolla att rätt antal lag är valda och visa gruppindelningen.
  function handleCalculate() {
    if (selectedTeams.length !== selectedNumParticipants) {
      alert(`Du måste välja exakt ${selectedNumParticipants} lag.`);
      return;
    }
    // Beräkna gruppstorlekar och etiketterna A,B,C,(D)
    computeGroupConfig(selectedNumParticipants);
    // Visa gruppindelningen och göm setup-sektionen
    document.getElementById('setup-section').classList.add('hidden');
    document.getElementById('assignment-section').classList.remove('hidden');
    renderGroupAssignment();
  }

  // Beräkna hur många grupper och storlekar beroende på deltagarantalet.
  function computeGroupConfig(n) {
    groupConfig = [];
    groupLabels = [];
    if (n === 16) {
      groupConfig = [4, 4, 4, 4];
      groupLabels = ['A', 'B', 'C', 'D'];
    } else {
      const groupCount = 3;
      const base = Math.floor(n / groupCount); // 12-15 deltagare ger bas 4 eller 5
      const remainder = n - base * groupCount;
      groupConfig = new Array(groupCount).fill(base);
      for (let i = 0; i < remainder; i++) {
        groupConfig[i] += 1;
      }
      groupLabels = ['A', 'B', 'C'];
    }
  }

  // Rendera formulär för att tilldela lag till slots i varje grupp.
  function renderGroupAssignment() {
    const container = document.getElementById('groups-container');
    container.innerHTML = '';
    slotAssignments = {};
    groupLabels.forEach((label, gIndex) => {
      const size = groupConfig[gIndex];
      const card = document.createElement('div');
      card.className = 'group-card';
      card.innerHTML = `<h3>Grupp ${label}</h3>`;
      for (let i = 0; i < size; i++) {
        const slot = `${label}${i + 1}`;
        const row = document.createElement('div');
        row.className = 'slot-row';
        const span = document.createElement('span');
        span.textContent = slot;
        const select = document.createElement('select');
        select.dataset.slot = slot;
        // tomt alternativ
        const blank = document.createElement('option');
        blank.value = '';
        blank.textContent = '--';
        select.appendChild(blank);
        selectedTeams.forEach(teamId => {
          const opt = document.createElement('option');
          opt.value = teamId;
          const team = availableTeams.find(t => t.id === teamId);
          opt.textContent = team ? team.name : teamId;
          select.appendChild(opt);
        });
        select.addEventListener('change', () => {
          slotAssignments[slot] = select.value;
          updateAssignmentSelects();
        });
        row.appendChild(span);
        row.appendChild(select);
        card.appendChild(row);
      }
      container.appendChild(card);
    });
  }

  // Se till att inget lag kan väljas på flera platser samtidigt.
  function updateAssignmentSelects() {
    const used = Object.values(slotAssignments).filter(v => v);
    document.querySelectorAll('#groups-container select').forEach(sel => {
      const currentVal = sel.value;
      sel.querySelectorAll('option').forEach(opt => {
        if (!opt.value) return;
        opt.disabled = (opt.value !== currentVal && used.includes(opt.value));
      });
    });
  }

  // När användaren klickar "Starta turnering". Kontrollera att alla slots har lag och starta gruppspelet.
  function handleStartTournament() {
    // kontrollera att alla positioner är fyllda
    for (const label of groupLabels) {
      const size = groupConfig[groupLabels.indexOf(label)];
      for (let i = 1; i <= size; i++) {
        const slot = `${label}${i}`;
        if (!slotAssignments[slot]) {
          alert('Alla positioner måste tilldelas ett lag.');
          return;
        }
      }
    }
    // initiera gruppspelet
    initGroupStage();
    document.getElementById('assignment-section').classList.add('hidden');
    document.getElementById('tournament-section').classList.remove('hidden');
    switchTab('games');
  }

  // Initierar matcher och tabeller för gruppspelet.
  function initGroupStage() {
    matches = [];
    groupTables = {};
    let matchCounter = 1;
    // bygg grupperna
    groupLabels.forEach(label => {
      const size = groupConfig[groupLabels.indexOf(label)];
      // skapa entries för tabell
      const entries = [];
      for (let i = 1; i <= size; i++) {
        const slot = `${label}${i}`;
        const teamId = slotAssignments[slot];
        entries.push({
          teamId,
          played: 0,
          wins: 0,
          draws: 0,
          losses: 0,
          goalsFor: 0,
          goalsAgainst: 0,
          points: 0,
          stableSeed: i // position i gruppen
        });
      }
      groupTables[label] = entries;
      // generera matcher (kombinationer av alla lag i gruppen)
      for (let i = 0; i < size; i++) {
        for (let j = i + 1; j < size; j++) {
          const slotHome = `${label}${i + 1}`;
          const slotAway = `${label}${j + 1}`;
          matches.push({
            id: 'G' + matchCounter++,
            homeSlot: slotHome,
            awaySlot: slotAway,
            homeTeam: slotAssignments[slotHome],
            awayTeam: slotAssignments[slotAway],
            homeScore: null,
            awayScore: null,
            played: false
          });
        }
      }
    });
    playoffStage = false;
    renderMatches();
    renderTables();
  }

  // Visa kommande matcher (upp till antalet bord) med formulär för resultat.
  function renderMatches() {
    const container = document.getElementById('current-matches');
    container.innerHTML = '';
    // endast gruppmatcher visas innan slutspel
    if (playoffStage) return;
    const pending = matches.filter(m => !m.played);
    const toShow = pending.slice(0, numTables);
    toShow.forEach(match => {
      const card = document.createElement('div');
      card.className = 'match-card';
      const header = document.createElement('div');
      header.className = 'match-header';
      header.textContent = `Match ${match.id}`;
      card.appendChild(header);
      const teamsRow = document.createElement('div');
      teamsRow.className = 'match-teams';
      // Home team
      const homeTeam = availableTeams.find(t => t.id === match.homeTeam);
      const homeDiv = document.createElement('div');
      homeDiv.className = 'team';
      const homeFlag = document.createElement('img');
      homeFlag.src = homeTeam ? homeTeam.flag : '';
      homeFlag.alt = homeTeam ? homeTeam.name : '';
      const homeSpan = document.createElement('span');
      homeSpan.textContent = homeTeam ? homeTeam.name : match.homeTeam;
      homeDiv.appendChild(homeFlag);
      homeDiv.appendChild(homeSpan);
      // Score inputs
      const scoreDiv = document.createElement('div');
      scoreDiv.className = 'score-inputs';
      const inHome = document.createElement('input');
      inHome.type = 'number';
      inHome.min = 0;
      inHome.value = match.homeScore !== null ? match.homeScore : '';
      const dash = document.createElement('span');
      dash.textContent = ' - ';
      const inAway = document.createElement('input');
      inAway.type = 'number';
      inAway.min = 0;
      inAway.value = match.awayScore !== null ? match.awayScore : '';
      scoreDiv.appendChild(inHome);
      scoreDiv.appendChild(dash);
      scoreDiv.appendChild(inAway);
      // Away team
      const awayTeam = availableTeams.find(t => t.id === match.awayTeam);
      const awayDiv = document.createElement('div');
      awayDiv.className = 'team';
      const awayFlag = document.createElement('img');
      awayFlag.src = awayTeam ? awayTeam.flag : '';
      awayFlag.alt = awayTeam ? awayTeam.name : '';
      const awaySpan = document.createElement('span');
      awaySpan.textContent = awayTeam ? awayTeam.name : match.awayTeam;
      awayDiv.appendChild(awayFlag);
      awayDiv.appendChild(awaySpan);
      // assemble row
      teamsRow.appendChild(homeDiv);
      teamsRow.appendChild(scoreDiv);
      teamsRow.appendChild(awayDiv);
      card.appendChild(teamsRow);
      // action button
      const btn = document.createElement('button');
      btn.className = 'primary-btn';
      btn.textContent = match.played ? 'Ändra' : 'Klar';
      btn.addEventListener('click', () => {
        const hs = parseInt(inHome.value, 10);
        const as = parseInt(inAway.value, 10);
        if (isNaN(hs) || isNaN(as)) {
          alert('Fyll i båda resultaten.');
          return;
        }
        handleMatchResult(match, hs, as);
      });
      card.appendChild(btn);
      container.appendChild(card);
    });
  }

  // När resultat registreras eller ändras för en match.
  function handleMatchResult(match, hs, as) {
    // om den redan var spelad, återställ statistik
    if (match.played) {
      updateStats(match, -match.homeScore, -match.awayScore);
    }
    match.homeScore = hs;
    match.awayScore = as;
    match.played = true;
    updateStats(match, hs, as);
    renderMatches();
    renderTables();
    // kontrollera om alla matcher är spelade
    if (matches.every(m => m.played)) {
      setupPlayoffs();
    }
  }

  // Uppdaterar tabellstatistiken för en match med delta-siffror.
  function updateStats(match, hs, as) {
    // hitta grupp och entries
    let groupLabel;
    groupLabels.forEach(label => {
      if (match.homeSlot.startsWith(label)) groupLabel = label;
    });
    const entries = groupTables[groupLabel];
    const homeEntry = entries.find(e => e.teamId === match.homeTeam);
    const awayEntry = entries.find(e => e.teamId === match.awayTeam);
    if (!homeEntry || !awayEntry) return;
    // uppdatera matcher spelade
    const deltaPlay = hs >= 0 ? 1 : -1;
    homeEntry.played += deltaPlay;
    awayEntry.played += deltaPlay;
    // mål
    homeEntry.goalsFor += hs;
    homeEntry.goalsAgainst += as;
    awayEntry.goalsFor += as;
    awayEntry.goalsAgainst += hs;
    // vinster, förluster, oavgjort och poäng
    if (hs > as) {
      homeEntry.wins += deltaPlay;
      homeEntry.points += 3 * deltaPlay;
      awayEntry.losses += deltaPlay;
    } else if (hs < as) {
      awayEntry.wins += deltaPlay;
      awayEntry.points += 3 * deltaPlay;
      homeEntry.losses += deltaPlay;
    } else {
      // oavgjort
      homeEntry.draws += deltaPlay;
      awayEntry.draws += deltaPlay;
      homeEntry.points += 1 * deltaPlay;
      awayEntry.points += 1 * deltaPlay;
    }
  }

  // Rendera grupptabeller.
  function renderTables() {
    const container = document.getElementById('tables-container');
    container.innerHTML = '';
    groupLabels.forEach(label => {
      const entries = groupTables[label];
      // sortera på poäng, målskillnad, gjorda mål, stabil seed
      const sorted = [...entries].sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        const gdA = a.goalsFor - a.goalsAgainst;
        const gdB = b.goalsFor - b.goalsAgainst;
        if (gdB !== gdA) return gdB - gdA;
        if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
        return a.stableSeed - b.stableSeed;
      });
      const table = document.createElement('table');
      table.className = 'group-table';
      const caption = document.createElement('caption');
      caption.textContent = `Grupp ${label}`;
      table.appendChild(caption);
      const thead = document.createElement('thead');
      const trh = document.createElement('tr');
      ['Lag','MP','W','D','L','GF','GA','GD','P'].forEach(col => {
        const th = document.createElement('th');
        th.textContent = col;
        trh.appendChild(th);
      });
      thead.appendChild(trh);
      table.appendChild(thead);
      const tbody = document.createElement('tbody');
      sorted.forEach(entry => {
        const tr = document.createElement('tr');
        const team = availableTeams.find(t => t.id === entry.teamId);
        const cells = [
          team ? team.name : entry.teamId,
          entry.played,
          entry.wins,
          entry.draws,
          entry.losses,
          entry.goalsFor,
          entry.goalsAgainst,
          entry.goalsFor - entry.goalsAgainst,
          entry.points
        ];
        cells.forEach(val => {
          const td = document.createElement('td');
          td.textContent = val;
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      container.appendChild(table);
    });
  }

  // Byt flik (matcher/tabeller, slutspel eller marathon).
  function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.add('hidden'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    const activeTab = document.getElementById(`${tabName}-tab`);
    if (activeTab) {
      activeTab.classList.remove('hidden');
      activeTab.classList.add('active');
    }
    const btn = document.querySelector(`.tab-btn[data-tab="${tabName}"]`);
    if (btn) btn.classList.add('active');
  }

  // Initiera slutspel när gruppspelet är klart. Skapar bracket med 8 lag.
  function setupPlayoffs() {
    playoffStage = true;
    // samla top 2 från varje grupp
    let seeds = [];
    groupLabels.forEach(label => {
      const sorted = [...groupTables[label]].sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        const gdA = a.goalsFor - a.goalsAgainst;
        const gdB = b.goalsFor - b.goalsAgainst;
        if (gdB !== gdA) return gdB - gdA;
        if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
        return a.stableSeed - b.stableSeed;
      });
      // Top 2
      seeds.push(Object.assign({ group: label }, sorted[0]));
      seeds.push(Object.assign({ group: label }, sorted[1]));
    });
    // om det finns färre än 8 lag (3 grupper), lägg till bästa tredjeplatser
    if (seeds.length < 8) {
      // samla tredjeplacerade
      let thirds = [];
      groupLabels.forEach(label => {
        const sorted = [...groupTables[label]].sort((a, b) => {
          if (b.points !== a.points) return b.points - a.points;
          const gdA = a.goalsFor - a.goalsAgainst;
          const gdB = b.goalsFor - a.goalsAgainst;
          if (gdB !== gdA) return gdB - gdA;
          if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
          return a.stableSeed - b.stableSeed;
        });
        thirds.push(Object.assign({ group: label }, sorted[2]));
      });
      // sortera tredjor
      thirds.sort((a, b) => {
        if (b.points !== a.points) return b.points - a.points;
        const gdA = a.goalsFor - a.goalsAgainst;
        const gdB = b.goalsFor - b.goalsAgainst;
        if (gdB !== gdA) return gdB - gdA;
        if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
        return a.stableSeed - b.stableSeed;
      });
      while (seeds.length < 8 && thirds.length) {
        seeds.push(thirds.shift());
      }
    }
    // sortera seeds övergripande
    seeds.sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      const gdA = a.goalsFor - a.goalsAgainst;
      const gdB = b.goalsFor - b.goalsAgainst;
      if (gdB !== gdA) return gdB - gdA;
      if (b.goalsFor !== a.goalsFor) return b.goalsFor - a.goalsFor;
      return a.stableSeed - b.stableSeed;
    });
    // Hämta teamId från seeds
    const seedIds = seeds.map(s => s.teamId);
    // skapa kvartsfinaler (1 vs 8, 4 vs 5, 3 vs 6, 2 vs 7)
    const qf = [
      { id: 'QF1', home: seedIds[0], away: seedIds[7], homeScore: null, awayScore: null, played: false, winner: null },
      { id: 'QF2', home: seedIds[3], away: seedIds[4], homeScore: null, awayScore: null, played: false, winner: null },
      { id: 'QF3', home: seedIds[2], away: seedIds[5], homeScore: null, awayScore: null, played: false, winner: null },
      { id: 'QF4', home: seedIds[1], away: seedIds[6], homeScore: null, awayScore: null, played: false, winner: null }
    ];
    // semifinaler och final läggs till efter att kvartsfinaler spelats
    playoffBracket = [
      { name: 'Kvartsfinaler', matches: qf },
      { name: 'Semifinaler', matches: [] },
      { name: 'Final', matches: [] }
    ];
    // visa slutspelstabben
    switchTab('playoffs');
    renderPlayoffs();
  }

  // Rendera playoff-bracket och hantera resultat.
  function renderPlayoffs() {
    const container = document.getElementById('playoff-bracket');
    container.innerHTML = '';
    playoffBracket.forEach((round, roundIndex) => {
      const roundDiv = document.createElement('div');
      roundDiv.className = 'playoff-round';
      const title = document.createElement('h3');
      title.textContent = round.name;
      roundDiv.appendChild(title);
      round.matches.forEach((match, idx) => {
        const card = document.createElement('div');
        card.className = 'match-card';
        // teaminfo
        const teamsRow = document.createElement('div');
        teamsRow.className = 'match-teams';
        // home
        const homeDiv = document.createElement('div');
        homeDiv.className = 'team';
        const homeTeam = availableTeams.find(t => t.id === match.home);
        const homeFlag = document.createElement('img');
        homeFlag.src = homeTeam ? homeTeam.flag : '';
        homeFlag.alt = homeTeam ? homeTeam.name : '';
        const homeSpan = document.createElement('span');
        homeSpan.textContent = homeTeam ? homeTeam.name : '';
        homeDiv.appendChild(homeFlag);
        homeDiv.appendChild(homeSpan);
        // scores
        const scoreDiv = document.createElement('div');
        scoreDiv.className = 'score-inputs';
        const inHome = document.createElement('input');
        inHome.type = 'number';
        inHome.min = 0;
        inHome.value = match.homeScore !== null ? match.homeScore : '';
        const dash = document.createElement('span');
        dash.textContent = ' - ';
        const inAway = document.createElement('input');
        inAway.type = 'number';
        inAway.min = 0;
        inAway.value = match.awayScore !== null ? match.awayScore : '';
        scoreDiv.appendChild(inHome);
        scoreDiv.appendChild(dash);
        scoreDiv.appendChild(inAway);
        // away
        const awayDiv = document.createElement('div');
        awayDiv.className = 'team';
        const awayTeam = availableTeams.find(t => t.id === match.away);
        const awayFlag = document.createElement('img');
        awayFlag.src = awayTeam ? awayTeam.flag : '';
        awayFlag.alt = awayTeam ? awayTeam.name : '';
        const awaySpan = document.createElement('span');
        awaySpan.textContent = awayTeam ? awayTeam.name : '';
        awayDiv.appendChild(awayFlag);
        awayDiv.appendChild(awaySpan);
        teamsRow.appendChild(homeDiv);
        teamsRow.appendChild(scoreDiv);
        teamsRow.appendChild(awayDiv);
        card.appendChild(teamsRow);
        // knapp
        const btn = document.createElement('button');
        btn.className = 'primary-btn';
        btn.textContent = match.played ? 'Ändra' : 'Klar';
        btn.addEventListener('click', () => {
          const hs = parseInt(inHome.value, 10);
          const as = parseInt(inAway.value, 10);
          if (isNaN(hs) || isNaN(as)) {
            alert('Fyll i båda resultaten.');
            return;
          }
          handlePlayoffResult(roundIndex, idx, hs, as);
        });
        card.appendChild(btn);
        roundDiv.appendChild(card);
      });
      container.appendChild(roundDiv);
    });
  }

  // Hantera resultat i slutspelsmatch.
  function handlePlayoffResult(roundIndex, matchIndex, hs, as) {
    const round = playoffBracket[roundIndex];
    const match = round.matches[matchIndex];
    // spara resultat
    match.homeScore = hs;
    match.awayScore = as;
    match.played = true;
    // bestäm vinnare
    if (hs > as) {
      match.winner = match.home;
    } else if (hs < as) {
      match.winner = match.away;
    } else {
      // vid lika vinner hemmalag
      match.winner = match.home;
    }
    // Om kvartsfinal: fördela semifinalmatcherna när alla kvartsfinaler spelats
    if (roundIndex === 0) {
      const qf = playoffBracket[0].matches;
      if (qf.every(m => m.played)) {
        const sfMatches = [];
        // Semifinal 1: vinnare QF1 vs vinnare QF3
        sfMatches.push({ id: 'SF1', home: qf[0].winner, away: qf[2].winner, homeScore: null, awayScore: null, played: false, winner: null });
        // Semifinal 2: vinnare QF2 vs vinnare QF4
        sfMatches.push({ id: 'SF2', home: qf[1].winner, away: qf[3].winner, homeScore: null, awayScore: null, played: false, winner: null });
        playoffBracket[1].matches = sfMatches;
      }
    }
    // Om semifinal: skapa final när båda semifinaler är spelade
    if (roundIndex === 1) {
      const sf = playoffBracket[1].matches;
      if (sf.every(m => m.played)) {
        const finalMatches = [];
        finalMatches.push({ id: 'F', home: sf[0].winner, away: sf[1].winner, homeScore: null, awayScore: null, played: false, winner: null });
        playoffBracket[2].matches = finalMatches;
      }
    }
    // uppdatera bracket
    renderPlayoffs();
  }
})();